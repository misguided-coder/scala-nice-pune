package com.example

import scala.collection.mutable.Map

class ProductNotFoundException(message: String) extends Exception(message)

class ShoppingCart {

  private var cart: Map[Int, Product] = Map()

  def addItemToCart(product: Product) {
    var productId = product.id
    if (cart.contains(productId)) {
      var existingProduct = cart(productId)
      existingProduct.qty = existingProduct.qty + 1
    } else {
      cart += (product.id -> product)
    }
  }

  def removeItemFromCart(id: Int) {
    if (!cart.contains(id)) {
      throw new ProductNotFoundException(s"Product with ${id} id not found in the cart.")
    }
    cart.remove(id)
  }

  def countItems(): Int = {
    var count: Int = 0
    for (product <- cart.values) {
      count = count + product.qty
    }
    return count
  }

  def totalPrice(): Double = {
    var total: Double = 0.00
    for (product <- cart.values) {
      var singlePrice = product.qty * product.price
      total = total + singlePrice
    }
    return total
  }

  def showCart(): List[Product] = {
    return cart.values.toList
  }

  def clearCart() {
    cart.clear
  }

}