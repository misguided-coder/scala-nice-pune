package com.example

case class Product(val id:Int,val name:String,var price:Double,var qty:Int) 