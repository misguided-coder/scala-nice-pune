package com.example

import org.scalatest.BeforeAndAfter
import org.scalatest.FunSuite
import org.scalatest.FunSpec
import com.example.ProductNotFoundException

class ShoppingCartTestSpecs extends FunSpec with BeforeAndAfter {

  var shoppingCart: ShoppingCart = _

  before {
    shoppingCart = new ShoppingCart
    //println("Inside before()")
  }

  after {
    shoppingCart = null
    //println("Inside after()")
  }

  describe("Shopping Cart") {

    describe("Adding Items") {

      it("should be zero item when empty") {
        assert(shoppingCart.showCart().size == 0)
      }

      it("should have 1 item when single item is added") {
        shoppingCart.addItemToCart(Product(100, "Dell Laptop", 12000.00, 1))
        assert(shoppingCart.showCart().size == 1)
      }

      it("should have 3 items when 3 items are added") {
        shoppingCart.addItemToCart(Product(100, "Dell Laptop", 12000.00, 1))
        shoppingCart.addItemToCart(Product(101, "Rolex Watch", 22000.00, 1))
        shoppingCart.addItemToCart(Product(103, "Samsung Mobile", 10000.00, 1))
        assert(shoppingCart.showCart().size == 3)
      }

      it("should increase same item quantity when added again") {
        shoppingCart.addItemToCart(Product(100, "Dell Laptop", 12000.00, 1))
        shoppingCart.addItemToCart(Product(100, "Dell Laptop", 12000.00, 1))
        for (product <- shoppingCart.showCart()) {
          assert(product.qty == 2)
        }
      }

      it("should have same item added") {
        shoppingCart.addItemToCart(Product(100, "Dell Laptop", 12000.00, 1))
        for (product <- shoppingCart.showCart()) {
          assert(product.id == 100)
          assert(product.name.equals("Dell Laptop"))
        }
      }
    }

    describe("Removing Items") {

      it("should remove same item which is removed") (pending)

      it("should remove full item when removed") {
        shoppingCart.addItemToCart(Product(100, "Dell Laptop", 12000.00, 1))
        shoppingCart.removeItemFromCart(100)
        assert(shoppingCart.showCart().size == 0)
      }

      it("should throw error when wrong item is removed") {
        shoppingCart.addItemToCart(Product(100, "Dell Laptop", 12000.00, 1))
        var exception = intercept[ProductNotFoundException] {
          shoppingCart.removeItemFromCart(200)
        }
        assert(exception.getMessage == "Product with 200 id not found in the cart.")
      }
    }

  }

}