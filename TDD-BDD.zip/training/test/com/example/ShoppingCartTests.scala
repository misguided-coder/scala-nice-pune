package com.example

import org.scalatest.BeforeAndAfter
import org.scalatest.FunSuite

class ShoppingCartTests extends FunSuite with BeforeAndAfter {

  var shoppingCart: ShoppingCart = _

  before {
    shoppingCart = new ShoppingCart
    println("Inside before()")
  }

  after {
    shoppingCart = null
    println("Inside after()")
  }

  test("new cart will have zero items") {
    assert(shoppingCart.showCart().size == 0)
  }

  test("adding one item will have 1 item") {
    shoppingCart.addItemToCart(Product(100, "Dell Laptop", 12000.00, 1))
    assert(shoppingCart.showCart().size == 1)
  }

  test("adding duplicate item will increase same item quantity") {
    shoppingCart.addItemToCart(Product(100, "Dell Laptop", 12000.00, 1))
    shoppingCart.addItemToCart(Product(100, "Dell Laptop", 12000.00, 1))
    for (product <- shoppingCart.showCart()) {
      assert(product.qty == 2)
    }
  }

  test("adding 3 items will have size 3 only") {
    shoppingCart.addItemToCart(Product(100, "Dell Laptop", 12000.00, 1))
    shoppingCart.addItemToCart(Product(101, "Rolex Watch", 22000.00, 1))
    shoppingCart.addItemToCart(Product(103, "Samsung Mobile", 10000.00, 1))
    assert(shoppingCart.showCart().size == 3)
  }

  test("adding an item should be same item in cart") {
    shoppingCart.addItemToCart(Product(100, "Dell Laptop", 12000.00, 1))
    for (product <- shoppingCart.showCart()) {
      assert(product.id == 100)
      assert(product.name.equals("Dell Laptop"))
    }
  }

  test("empty cart should not return null")(pending)

  test("remove wrong item should result in exception")(pending)

}