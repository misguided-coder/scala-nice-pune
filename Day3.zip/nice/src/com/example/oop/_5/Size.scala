package com.example.oop._5

class Size (w: Int, h: Int) {

  var width: Int = w
  var height: Int = h

  def info() {
    println(s"W : ${width}, H : ${height}")
  }

  def plus(size: Size): Size = {
    new Size(this.width + size.width, this.height + size.height)
  }

  def +(size: Size): Size = {
    new Size(this.width + size.width, this.height + size.height)
  }

  def -(size: Size): Size = {
    new Size(this.width - size.width, this.height - size.height)
  }
  
}