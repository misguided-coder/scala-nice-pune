package com.example.oop._3

class Employee(val id: Int = 100, val name: String = "Jaggu", var salary: Double = 25000.00) {

  def info(): Unit = {
    println(s"ID : ${this.id}")
    println(s"Name : ${this.name}")
    println(s"Salary : ${salary}")
    println("==============================")
  }

  def applyForLeave(): Unit = {
    println(s"${this.name} applied for 2 year long holiday!!")
  }

  def assignProject(projectName: String): Unit = {
    println(s"${this.name} has been assigned ${projectName} project!!")
  }

  def updateSalary(percentage: Double): Unit = {
    this.salary = this.salary + (this.salary * percentage)
    println(s"${this.name} salary has been updated and latest salary is Rs/- ${this.salary}!!")
  }

}