package com.example.oop._2

object EmployeeDemo {

  def main(arg: Array[String]): Unit = {
    UC1()
  }

  def UC1() {
    var e1 = new Employee(1,"Raj",12000.00)
    var e2 = new Employee(2,"Rohan",15000.00)

    e1.info()
    e2.info()
    e1.applyForLeave()
    e2.applyForLeave()
    e1.assignProject("Core Banking App")
    e2.assignProject("Core Banking App")
    e1.updateSalary(0.60)
    e2.updateSalary(0.60)
  }

}