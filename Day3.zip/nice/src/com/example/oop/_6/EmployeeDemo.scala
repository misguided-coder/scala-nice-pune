package com.example.oop._6

object EmployeeDemo {

  def main(arg: Array[String]): Unit = {

    var e1 = new Employee(1, "Ram", 5000.00)

    //println(e1.id)
    println(e1.name)
    println(e1.salary)

    e1.name = "Mohan"

    println(e1.name)

  }

}