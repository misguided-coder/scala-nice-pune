package com.example.oop._4

class Employee(val id: Int, val name: String, var salary: Double) {

  def this(id: Int, name: String) {
    this(id, name, 1000.00)
  }

  def this(id: Int, salary: Double) {
    this(id, "Jaggu", salary)
  }

  def this(id: Int) {
    //this(id, "Jaggu", 1000.00)
    this(id, "Jaggu")
  }

  def this() {
    this(1, "Jaggu", 1000.00)
  }

  def info(): Unit = {
    println(s"ID : ${this.id}")
    println(s"Name : ${this.name}")
    println(s"Salary : ${salary}")
    println("==============================")
  }

  def applyForLeave(): Unit = {
    println(s"${this.name} applied for 2 year long holiday!!")
  }

  def assignProject(projectName: String): Unit = {
    println(s"${this.name} has been assigned ${projectName} project!!")
  }

  def updateSalary(percentage: Double): Unit = {
    this.salary = this.salary + (this.salary * percentage)
    println(s"${this.name} salary has been updated and latest salary is Rs/- ${this.salary}!!")
  }

}