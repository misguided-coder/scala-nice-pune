package com.example.traits

object Main {

  def main(arg: Array[String]): Unit = {

    var simpleQuote = new SimpleQuote()
    println(simpleQuote.nextQuote())

    var everyDayQuote = new EveryDayQuote()
    println(everyDayQuote.nextQuote())
  

  }

}