package com.example.traits

trait QuoteSupplier {

  var quotes = Array[String](
    "I do not care anybody, but I respect everybody",
    "Someone give me loan and leave me alone",
    "Life is one time offer, live it",
    "Man health is judged by at what he takes 2 at a time - Pills or Stairs")

  //abstract method
  def addQuote(quote:String): Unit
    
  //concrete method
  def loadQuotes: Array[String] = quotes
}