package com.example.conditions

import java.util.Date

object MatchCaseDemo {

  def main(arg: Array[String]): Unit = {
    //UC1()
    //UC2()
    //UC3()
    //UC4()

    println(chooseColor("Blue"))
    println(pickColor("Yellow"))

  }

  def pickColor(color: String): String = color match {
    case "Red" => "Red is sun color!!"
    case "Green" => "Grean is a peace color!!"
    case "Blue" => "Blue is cool color!!"
    case "Yellow" => "Yellow is attractive color!!"
    case _     => "Color is white!!"
  }

  def chooseColor(color: String): String = {
    if (color.equals("Red"))
      return "Red is sun color!!"
    if (color.equals("Green"))
      return "Grean is a peace color!!"
    if (color.equals("Blue"))
      return "Blue is cool color!!"
    if (color.equals("Yellow"))
      return "Yellow is attractive color!!"
    return "Color is white!!"
  }

  def UC4() {

    var data: Any = new Date()

    var result: String = data match {
      case 200        => s"Play with ${data} number"
      case data: Int  => "Play with any number"
      case "Red"      => "Red is a nice color"
      case 400000.00  => "You are getting good salary"
      case data: Date => s"You were born on ${data}"
      case _          => "Data is unknown!!"
    }

    println(result)

  }

  def UC3() {

    var data: Any = new Date()

    data match {
      case 200        => println(s"Play with ${data} number")
      case data: Int  => println("Play with any number")
      case "Red"      => println("Red is a nice color")
      case 400000.00  => println("You are getting good salary")
      case data: Date => println(s"You were born on ${data}")
      case _          => println("Data is unknown!!")
    }

  }

  def UC2() {

    var salary: Int = 40000

    salary match {
      case 10000 | 20000 => println("Very Poor Employee")
      case 30000 | 40000 => println("Rich Employee")
      case 50000 | 60000 => println("Very Rich Employee")
      case _             => println("Very Secret Salary")
    }

  }

  def UC1() {

    var salary: Int = 80000

    salary match {
      case 10000 => println("Very Poor Employee")
      case 20000 => println("Poor Employee")
      case 30000 => println("Rich Employee")
      case 40000 => println("Very Rich Employee")
      case 50000 => println("Very Very Rich Employee")
      //case default =>  println("Secret Salary")
      case _     => println("Very Secret Salary")
    }

  }

}