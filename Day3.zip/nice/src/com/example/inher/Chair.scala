package com.example.inher

//class Chair extends Furniture(1001,"Wood",4500.00) {
class Chair(id: Int, material: String, price: Double) extends Furniture(id, material, price) {

  var legs: Int = 4
  var hands: Int = 2

  def this() {
    this(1, "Wood", 100.00)
  }

  def this(legs: Int, hands: Int) {
    this(1, "Wood", 100.00)
    this.legs = legs
    this.hands = hands
  }

  def this(id: Int, material: String, price: Double, legs: Int, hands: Int) {
    this(id, material, price)
    this.legs = legs
    this.hands = hands
  }

  override def info() {
    super.info
    println(s"Legs : ${legs}")
    println(s"Hands : ${hands}")
  }
  
  override def paint() {
    println(s"Chair is painted with shower brush!!")
  }
  
}