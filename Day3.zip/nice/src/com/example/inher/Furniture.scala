package com.example.inher

class Furniture(id: Int, material: String, price: Double) {

  def info() {
    println(s"ID : ${id}")
    println(s"Material : ${material}")
    println(s"Price : ${price}")
  }

  def make() {
    println(s"Furniture is made of ${this.material}")
  }

  def paint() {
    println(s"Furniture is painted and ready!!")
  }

  def sell() {
    println(s"Furniture is ready to be sold in Rs/- ${this.price} !!")
  }

}