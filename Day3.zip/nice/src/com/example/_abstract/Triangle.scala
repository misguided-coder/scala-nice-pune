package com.example._abstract

class Triangle extends Shape {

  override def draw() {
    println("Triangle is ready on paper!!")
  }

  override def paint() {
    println("Triangle is painted with hand!!")
  }
}