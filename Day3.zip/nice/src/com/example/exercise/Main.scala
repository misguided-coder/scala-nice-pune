package com.example.exercise

//Developer B is using API provided by Developer A
object Main {
  
  def main(arg:Array[String]) :Unit = {
    
    var a = () => { println("Simple Math Calculator") }
    Calculator.info(a);
    Calculator.info(() => { println("Math Calculator") });

    Calculator.doCal((a: Int, b: Int) => a + b)
    Calculator.doCal((a: Int, b: Int) => a - b)
    Calculator.doCal((a: Int, b: Int) => a * b)
    Calculator.doCal((a: Int, b: Int) => a / b)
    Calculator.doCal((a: Int, b: Int) => a + a + b)
    Calculator.doCal((a: Int, b: Int) => a * b * b * a)
    Calculator.doCal((a: Int, b: Int) => a % b)
    Calculator.doCal((a: Int, b: Int) => a + b + 100)
    Calculator.doCal((a: Int, b: Int) => a / b * a - 10)
    Calculator.doCal((a: Int, b: Int) => a + b - 90)
    
    DataList.filter((name:String)=> name.startsWith("R"))
    DataList.filter((name:String)=> name.endsWith("a"))
    DataList.filter((name:String)=> name.length > 4)
    
  }
  
}