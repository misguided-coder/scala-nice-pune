package com.example.exercise

object DataList {

  def filter(fn: (String) => Boolean) {
    var names = Array("Rani", "Ramu", "Chachu", "Ganshu", "Papa Jon", "Rancho", "Sudhir",
      "Pintu", "Jaggu", "Chandu", "Gabbar", "Lalu Yadav", "Kalia Khatarnak", "Kallu Don", "Rani Patiala",
      "Rose Gulabi", "Laden Humble", "Dawood Raja")

    var idx = 0;
    while (idx < names.length) {

      if (fn(names(idx))) {
        println(names(idx))
      }

      idx += 1
    }
    println("===========================================")
  }

}