package com.example.singleton._1

object Main {

  def main(arg: Array[String]): Unit = {
    
      var airport1 = Airport
      var airport2 = Airport
  
      println(airport1)
      println(airport2)
      
      airport1.info
      airport2.info
      Airport.info
      Airport.landPlane()
      Airport.landPlane()
      Airport.landPlane()
      Airport.landPlane()
      Airport.info
      airport1.info
      
      println(airport1.hashCode())
      println(airport2.hashCode())
      println(Airport.hashCode())
      
      
     
  }

}