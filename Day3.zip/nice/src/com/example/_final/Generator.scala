package com.example._final

class Generator {

  final val title: String = "Sequence Generator"
  final var version: String = "1.0.0"
  val seed: Int = 1000

  final def generate(): Long = {
    (Math.random() * seed).toLong
  }

}