package com.example._final

object Main {

  def main(arg: Array[String]): Unit = {
    var uniqueGenerator = new UniqueGenerator
    println(uniqueGenerator.generate)
  }

}