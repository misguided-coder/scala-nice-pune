package com.example.annonymous

import java.util.Date

object Main {

  def main(args: Array[String]): Unit = {
    println("Lets create function without names!!!!")
    greet("Jaggu")

    var i = 1000
    var d = new Date()

    x("Ram")
    
    println(x)
    println(x.getClass())
    println(x.getClass)
    println(x getClass)
    
    y()
    println(y getClass)
    
    var result = z()
    println(result)
    println(result getClass)
  }

  var z  = () => {
    println("Doing some calculations......")
    340+200-5/80
  }
  
   var y = () => println("Life is cool")
 
  //var y = () => printf("Life is cool")
  
  //var y = () => { printf("Life is cool") }

  /*var y = () => {
    printf("Life is cool");
  }*/

  //function expression
  var x = (name: String) => {
    printf("Hi %s%n", name);
  }

  //function definition
  def greet(name: String): Unit = {
    printf("Hello %s%n", name);
  }

}