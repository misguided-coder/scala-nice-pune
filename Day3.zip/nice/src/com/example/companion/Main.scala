package com.example.companion

object Main {

  def main(arg: Array[String]): Unit = {
    Cat.info()
    new Cat().drink
  }
}

class Cat {

  private var name: String = "Lucy"

  def drink() {
    println(s"${this.name} can drink ${Cat.diet}")
  }

}

object Cat {

  private var diet: String = "20 litre milk every day"

  def info() {
    var cat = new Cat()
    println(s"${cat.name}")
  }

}

