package com.example.functions.curry

object WeatherService {

  def main(arg: Array[String]): Unit = {

    showWeather("Pune", 12)
    showWeather("Pune", 15)
    showWeather("Pune", 22)
    showWeather("Pune", 30)
    showWeather("Pune", 5)

    var displayDelhiWeather = displayWeather("Delhi")
    var displayPuneWeather = displayWeather("Pune")

    displayDelhiWeather(10)
    displayDelhiWeather(12)
    displayDelhiWeather(15)
    displayDelhiWeather(20)
    displayDelhiWeather(24)

    displayPuneWeather(2)
    displayPuneWeather(4)
    displayPuneWeather(16)

  }

  //Curried Way of declaring functions
  var displayWeather = (city: String) => {
    (day: Int) =>
      {
        printf("%s Weather on %s day is %s!!%n", city, day, (Math.random() * 30).toInt)

      }
  }

  var showWeather = (city: String, day: Int) => {
    printf("%s Weather on %s day is %s!!%n", city, day, (Math.random() * 30).toInt)
  }

}