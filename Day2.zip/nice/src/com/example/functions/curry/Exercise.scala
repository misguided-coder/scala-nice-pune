package com.example.functions.curry

object Exercise {

  def main(arg: Array[String]): Unit = {
    grow()()()()(35)
  }

  var grow = () => {
    println("I am just new born infant!!")
    () => {
      println("I am now little grown!!")
      () => {
        println("I am now young!!")
        () => {
          println("I am now strong enough to fight!!")
          (age: Int) => {
            printf("I am now %s yrs old and can kill others!!%n", age)
          }
        }
      }
    }
  }

}