package com.example.functions.closure

object Main {

  def main(arg: Array[String]): Unit = {

    var inner = generate()
    println(inner())
    
  }

  var generate= () => {
    var seed = 5000
    () => {
      println("Generating unique sequences.....")
      (seed * Math.random()).toLong
    }
  }

}