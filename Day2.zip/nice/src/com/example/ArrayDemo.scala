package com.example

object ArrayDemo {

	def main(args:Array[String]) : Unit = {
		//UC1()
		//UC2()
		//UC3()
		UC4()
	}	



	def UC4() : Unit = {

		var numbers = Array.ofDim[Int](4,2)

		numbers(0)(0) = 1001
		numbers(0)(1) = 1002

		numbers(1)(0) = 1002
		numbers(1)(1) = 1002


		println(numbers(0)(0))
		println(numbers(1)(1))
	}


	def UC3() : Unit = {

		var numbers = Array.ofDim[Int](2)

		numbers(0) = 1001
		numbers(1) = 1002

		println(numbers(0))
		println(numbers(1))
	}


	def UC2() : Unit = {

		var numbers:Array[Array[Int]] = new Array[Array[Int]](4);

		numbers(0) = new Array[Int](2)
		numbers(1) = new Array[Int](2) 
		numbers(2) = new Array[Int](2)
		numbers(3) = new Array[Int](2)

		numbers(0)(0) = 1001
		numbers(0)(1) = 1002

		numbers(1)(0) = 2001
		numbers(1)(1) = 2002
 
		numbers(2)(0) = 3001
		numbers(2)(1) = 3002

		numbers(3)(0) = 4001
		numbers(3)(1) = 4002

		println(numbers(1)(1));
		println(numbers(3)(0));
 	
	}	


	def UC1() : Unit = {

		//var numbers:Array[Int] = new Array[Int](4);
		var numbers = new Array[Int](4); //data type inference
		println(numbers.getClass)
			
		numbers(0) = 100
		numbers(1) = 200
		numbers(2) = 300
		numbers(3) = 400
		
		println(numbers.length)
		println(numbers(0))
		println(numbers(1))
		println(numbers(2))
		println(numbers(3))
	}	

}