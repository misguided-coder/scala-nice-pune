package com.example.loops

object Main {

  def main(arg: Array[String]): Unit = {
    
    var count = 1

    while (count != 10) {
      println(s"Current Value is ${count}")
      count += 1
    }

    
    count = 1

    do {
      println(s"Current Value is ${count}")
      count += 1
    } while (count != 10)

  }

}