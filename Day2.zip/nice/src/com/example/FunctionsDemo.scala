package com.example

object FunctionsDemo {

	def main(args:Array[String]) : Unit = {
		hello()
		hello 
	
		greet("Rohan")
		greet()

		info("Raj",40) //positional arguments
		info("Raj")
		info()
		info(name="Raj",age=40) //named arguments
		info(age=40,name="Raj") //named arguments

		var result = generate()
		println("Result "+result);
		println("Result "+result.getClass());

		println(gen);
		

	}

	def gen = 200/2*5 

	//def gen() = 200/2*5 
	
	//def gen() :Int = 200/2*5 
	
	//def gen() :Int = { 200/2*5 }

	/*def gen() :Int = {
		200/2*5
	}*/	

	def generate() :Int = {
		println("Generating value......")
		200
	}	

	def info(name:String = "Jaggu",age:Int = 30) :Unit =  {
		println("Hello Mr "+name);
		println("Your age is "+age);
	}	

	def greet(name:String = "Jaggu") :Unit =  {
		println("Hello Mr "+name);
	}	

	def hello() :Unit =  {
		println("Hello Mr");
	}	
	
}