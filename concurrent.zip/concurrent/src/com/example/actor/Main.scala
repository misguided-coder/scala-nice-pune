package com.example.actor

import akka.actor.Actor
import akka.actor.ActorSystem
import akka.actor.Props

class SimpleActor extends Actor {

  def receive() = {

    case "holiday" => println("Holiday time, Let us enjoy!!")
    case "movie"   => println("Movie time, Let us enjoy!!")
    case message:Int   => println(s"${message}")
    case _         => println("Work time!!")
  }

}

object Main {

  def main(arg: Array[String]): Unit = {

    var actorSystem = ActorSystem("SimpleActorSystem")
    var props = Props[SimpleActor]
    var actor = actorSystem.actorOf(props,"SimpleActor")
      
    actor.tell("movie",null) 
    actor.!("holiday")
    actor ! "holiday"
    actor ! "sleep"
    actor ! 120
    actor ! true
    
  }

}