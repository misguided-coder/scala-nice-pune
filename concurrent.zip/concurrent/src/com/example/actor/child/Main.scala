package com.example.actor.child

import akka.actor.Actor
import akka.actor.ActorSystem
import akka.actor.Props
import java.util.concurrent.TimeUnit

class BossActor extends Actor {

  var actor = context.actorOf(Props[JuniorActor], "JuniorActor")

  def receive() = {

    case message: String =>
      println(s"${self.path.name} received message : ${message}")
      println(s"${self.path.name} is available at  : ${self.path}")
      actor ! "Wakeup"
    case _ => println("Work time!!")

  }

}

class JuniorActor extends Actor {

  def receive() = {

    case message: String =>
      println(s"${self.path.name} received message : ${message}")
      println(s"${self.path.name} is available at  : ${self.path}")
      println("Replying to Boss")
      TimeUnit.SECONDS.sleep(2)
      sender() ! "I am sleeping, will wakeup after 10 days"
    case _ => println("Work time!!")
  }

}

object Main {

  def main(arg: Array[String]): Unit = {

    var actorSystem = ActorSystem("SimpleActorSystem")
    var actor = actorSystem.actorOf(Props[BossActor], "BossActor")

    actor ! "sleep"

  }

}