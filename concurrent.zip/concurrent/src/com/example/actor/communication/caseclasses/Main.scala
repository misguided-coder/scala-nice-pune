package com.example.actor.communication.caseclasses

import akka.actor.Actor
import akka.actor.ActorSystem
import akka.actor.Props
import java.util.concurrent.TimeUnit
import akka.actor.ActorRef

case class CreateActor(var name: String)
case class KillActor(var name: String)
case object WakeUpMessage
case object SleepMessage

class BossActor extends Actor {
  var actor: ActorRef = null

  def receive() = {
    case CreateActor(name) =>
      actor = context.actorOf(Props[JuniorActor], s"${name}")
    case KillActor(name) =>
      context.system.stop(actor)
    case SleepMessage =>
      actor ! WakeUpMessage
    case data: String =>
      println(data)

  }

}

class JuniorActor extends Actor {

  def receive() = {

    case WakeUpMessage =>
      println(s"${self.path.name} received message : Wakeup call!!")
      println(s"${self.path.name} is available at  : ${self.path}")
      println("Replying to Boss")
      TimeUnit.SECONDS.sleep(2)
      sender() ! "I am sleeping, will wakeup after 10 days"
    case _ => println("Work time!!")
  }

}

object Main {

  def main(arg: Array[String]): Unit = {

    var actorSystem = ActorSystem("SimpleActorSystem")
    var actor = actorSystem.actorOf(Props[BossActor], "BossActor")

    actor ! CreateActor("Raju")
    actor ! CreateActor("Ram")
    actor ! CreateActor("Raj")
    actor ! CreateActor("Mohan")

    actor ! SleepMessage

  }

}