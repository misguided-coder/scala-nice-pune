package com.example.actor.lifecycle

import akka.actor.Actor
import akka.actor.ActorSystem
import akka.actor.Props
import java.util.concurrent.TimeUnit

class NoFundsException(message: String) extends Exception(message)

class SimpleActor extends Actor {

  def receive() = {

    case "holiday"    => println("Holiday time, Let us enjoy!!")
    case "movie"      => println("Movie time, Let us enjoy!!")
    case "deposit"    => throw new NoFundsException("Sorry, no money to deposit")
    case message: Int => println(s"${message}")
    case _            => println("Work time!!")
  }

  override def preStart() {
    println(s"${self.path.name} is about to start!!")
  }

  override def postStop() {
    println(s"${self.path.name} has been stopped and doing clean up work!!")
  }

  override def preRestart(reason: Throwable, message: Option[Any]) {
    println(s"${self.path.name} is about to restart and reason behind is : ${reason.getMessage}!!")
  }

  override def postRestart(reason: Throwable) {
    println(s"${self.path.name} has been restarted and reason behind is : ${reason.getMessage}!!")
  }

}

object Main {

  def main(arg: Array[String]): Unit = {

    var actorSystem = ActorSystem("SimpleActorSystem")
    var props = Props[SimpleActor]
    var actor = actorSystem.actorOf(props, "SimpleActor")

    actor.tell("movie", null)
    actor.!("holiday")
    actor ! "holiday"
    actor ! "sleep"
    actor ! "deposit"
    actor ! 120
    actor ! true

    TimeUnit.SECONDS.sleep(2)
    println(s"Stopping ${actor.path.name}")
    actorSystem.stop(actor)
  }

}