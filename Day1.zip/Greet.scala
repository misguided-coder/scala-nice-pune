object Greet extends App {
	println("Good Noon to Scalable Language!!!!");
}