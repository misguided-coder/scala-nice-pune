def doWork() : Unit = {
	println("Hi to Scalable Language!!!!");
}	

doWork();
doWork()
