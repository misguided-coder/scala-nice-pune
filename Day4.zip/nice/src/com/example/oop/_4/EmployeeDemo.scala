package com.example.oop._4

object EmployeeDemo {

  def main(arg: Array[String]): Unit = {
    //UC1()
    //UC2()
    UC3()
  }

  def UC3() {

    var e1 = new Employee(1, "Rohan", 15000.00)
    var e2 = new Employee(1, "Rohan", 15000.00)

    println(e1 == e2)
    println(e1.equals(e2))
    println(e1.eq(e2))
  }

  def UC2() {

    var e1 = new Employee(1, "Rohan", 15000.00)
    var e2 = new Employee(2, "Rohan")
    var e3 = new Employee(3)
    var e4 = new Employee()
    var e5 = new Employee(id = 1, name = "Rohan", salary = 15000.00)
    var e6 = new Employee(salary = 15000.00, id = 1, name = "Rohan")
    var e7 = new Employee(salary = 15000.00, id = 1)

  }

  def UC1() {
    var e1 = new Employee()
    var e2 = new Employee(2, "Rohan", 15000.00)

    e1.info()
    e2.info()
    e1.applyForLeave()
    e2.applyForLeave()
    e1.assignProject("Core Banking App")
    e2.assignProject("Core Banking App")
    e1.updateSalary(0.60)
    e2.updateSalary(0.60)
  }

}