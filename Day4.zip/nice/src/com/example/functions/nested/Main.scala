package com.example.functions.nested

object Main {

  var greet = () => println("Good Morning")

  def main(arg: Array[String]): Unit = {
    var greet = () => println("Good Afternoon")
    greet()
    hello()
  }

  def hello() {
    greet()
    println("Hello ji")

    def hi() {
      println("Hi ji")

    }

    hi()

    var bye = () => {
      println("Bye ji")
    }

    bye()

  }

}