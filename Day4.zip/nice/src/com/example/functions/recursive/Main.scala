package com.example.functions.recursive

object Main {

  def main(arg: Array[String]): Unit = {
    show(10)
  }

  def show(value: Int) {
    var arg = value
    println(s"Current Value is : ${value}")
    arg -= 1
    if(arg > 0)
      show(arg)
  }

}