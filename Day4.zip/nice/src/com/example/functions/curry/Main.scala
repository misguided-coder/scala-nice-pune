package com.example.functions.curry

object Main {

  def main(arg: Array[String]): Unit = {
    var a = doWork()
    a()

    doWork()()
  }

  var doWork = () => {
    println("Doing some work......")
    () => println("Doing some more work......")
  }

  /*def doWork(): () => Unit = {
    println("Doing some work......")
    () => println("Doing some more work......")
  }*/

  /*def doWork(): () => Unit = {
    println("Doing some work......")
    return () => println("Doing some more work......")
  }*/

  /*def doWork(): () => Unit = {
    println("Doing some work......")
    var work = () => println("Doing some more work......")
    return work
  }*/

}