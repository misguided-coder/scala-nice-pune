package com.example.traits.exercise

class Erikshaw extends Vehicle with Repairable {

  override def start() {
    println("Erikshaw engine is just switched on using button press!!")
  }

  def repair() {
    println(s"Erikshaw is repaired!!")
  }

}