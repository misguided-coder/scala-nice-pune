package com.example.traits.exercise

import jdk.nashorn.internal.ir.WithNode

object Main {

  def main(arg: Array[String]): Unit = {

    //Define system objects
    var car = new Car()
    var luxuryCar = new LuxuryCar()
    var bus = new Bus()
    var bike = new Bike()
    var erikshaw = new Erikshaw()

    //Define system users
    Driver.doDrive(car)
    Driver.doDrive(luxuryCar)
    Driver.doFly(luxuryCar)
    Driver.doDrive(bus)
    Driver.doDrive(bike)
    Driver.doDrive(erikshaw)
    
    Racer.doRace(car)
    Racer.doRace(bus)
    Racer.doRace(bike)
 
    Mechanic.doRepair(car)
    Mechanic.doRepair(bus)
    Mechanic.doRepair(erikshaw)
    
    HouseKeeper.doClean(car)
    HouseKeeper.doClean(bike)
    
    var luxuryBus = new Bus() with Washable
    HouseKeeper.doClean(luxuryBus)
    
  }

}