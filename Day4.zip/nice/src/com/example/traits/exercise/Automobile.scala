package com.example.traits.exercise

abstract class Automobile {
  
  def start
  
  def stop() {
    println("Automobile engine is shut down!!")  
  }
}