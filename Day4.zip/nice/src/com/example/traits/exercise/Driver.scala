package com.example.traits.exercise

object Driver extends Logger {

  def doDrive(vehicle: Vehicle) {
    log("Driver is ready to drive vehicle!!")
    vehicle.start()
    /*if (vehicle.isInstanceOf[Fly]) {
      var fly = vehicle.asInstanceOf[Fly]
      fly.canFly()
    }*/
    vehicle.speedDown()
    vehicle.stop()
    log("Driver finished the trip!!")
  }

  def doFly(vehicle: Fly) {
    println("Driver is ready to drive vehicle!!")
    vehicle.canFly()
    println("Driver finished the trip!!")
  }
}