package com.example.traits.exercise

trait Brakable {
  def speedDown  
}