package com.example.traits.exercise

object HouseKeeper {

  def doClean(vehicle: Washable) {
    println("HouseKeeper is ready to clean!!")
    vehicle.clean
    println("HouseKeeper finished the cleaning!!")
  }

}