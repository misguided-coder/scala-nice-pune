package com.example.traits.exercise

class Bike extends Vehicle with Acceleratable with Washable {

  var speed: Int = 120

  override def start() {
    println("Bike engine is just switched on using button press!!")
  }

  def speedUp() {
    this.speed += 10
    println(s"Bike is speeding up and current speed is ${this.speed} miles per hour!!")
  }

  override def clean() {
    println(s"Bike washing is done!!")
  }

}