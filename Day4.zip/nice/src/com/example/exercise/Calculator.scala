package com.example.exercise

//Developer A is designing API for other developers
object Calculator {
  
  def doCal(fn: (Int,Int) => Int) {
    println("Started Calculations!!")
    printf("Result : %s%n",fn(20,10))
    println("Finished Calculations!!")
  }

  def info(fn: () => Unit) {
    println("Started Work!!")
    fn()
    println("Finished Work!!")
  }

}