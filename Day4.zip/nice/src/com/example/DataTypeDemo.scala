package com.example

object DataTypeDemo {

	def main(args:Array[String]) : Unit = {

		var data:Any = "Ram"
		println(data)
		println(data.getClass())
	
		data = 90
		println(data)
		println(data.getClass())

		
		//mutable data
		var i = 100   //data type inference 
		println(i)
		println(i.getClass())

		var j:Int = 200 //explicit data type
		println(j)
		println(j.getClass())

		i = 1
		j = 2

		println(i)
		println(j)

		var salary:Double =  240000.00
		println(salary)
		println(salary.getClass())

		//immutable values
		val a = 100 //data type inference	
		println(a)
		println(a.getClass())

		val b:Int = 100 //explicit data type 
		println(b)
		println(b.getClass())
		
		
	}	
}