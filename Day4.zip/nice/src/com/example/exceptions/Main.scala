package com.example.exceptions

class ValueNotInRangeException(val message: String) extends Exception(message)
class InvalidAgeException(val message: String) extends Exception(message)

object Cinema {

  def wathMovie(age: Int) {
    if (age < 5 || age > 100)
      throw new ValueNotInRangeException("Invalid Range")
    if (age < 18)
      throw new InvalidAgeException("Invalid Age")
    println("Enjoy the movie with popcorn!!")
  }

}

object Main {

  def main(arg: Array[String]): Unit = {

    try {
      
      Cinema.wathMovie(24)
      
      var numbers: Array[Int] = new Array[Int](5)
      numbers(0) = 1000
      //numbers(6) = 6000

      var i = 10
      var j = 2
      var k = i / j
      println(k)
    } catch {
      case ex: ValueNotInRangeException            => println(s"${ex.message} ---- Your age is not in suitalbe for the movie,Go Home!!")
      case ex: InvalidAgeException            => println(s"${ex.message} ---- You are too young for the movie, Go Home!!")
      case ex: ArithmeticException            => println("I just handled devide by zero exception!!")
      case ex: NullPointerException           => println("I just handled null exception!!")
      case ex: ArrayIndexOutOfBoundsException => println("I just handled index out of bound exception!!")
      case ex: Exception                      => println("I just handled general exception!!")
    } finally {
      println("I am the boss")
    }
  }

}