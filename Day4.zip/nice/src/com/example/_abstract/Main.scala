package com.example._abstract

object Main {

  def main(arg: Array[String]): Unit = {
    var shape1 = new Triangle
    shape1.info
    shape1.draw
    shape1.paint
    
  }

}