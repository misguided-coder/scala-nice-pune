package com.example.caseclasses._1

case class Car(vin: Int, var model: String, var make: String) {

  def display() {
    println(this.vin)
    println(this.model)
    println(this.make)
  }

}

object Main {

  def main(arg: Array[String]): Unit = {
    //UC1()
    //UC2()
    //UC4()
    //UC5()
    //UC6()
    UC7()
  }

  def UC7() {

    var car1 = new Car(1, "Q5", "Audi")
    println(car1.vin)
    println(car1.model)
    println(car1.make)
    car1.model = "Q7"
    println(car1.model)

    car1.display()
  }

  def UC6() {

    var car1 = new Car(1, "Q5", "Audi")

    println(car1.productPrefix)
    println(car1.productArity)
    println(car1.productElement(0))
    println(car1.productElement(1))
    println(car1.productElement(2))

    var itertor = car1.productIterator
    while (itertor.hasNext) {
      println(itertor.next)
    }
  }

  def UC5() {

    var car1 = new Car(1, "Q5", "Audi")
    var Car(_, make, model) = car1

    println(model)
    println(make)
  }

  def UC4() {

    var car1 = new Car(1, "Q5", "Audi")
    var car2 = Car(2, "Q7", "Audi")
    var car3 = Car.apply(3, "X5", "BMW")
    var car4 = car3.copy(4, "X6", "BMW")
    var car5 = car3.copy(5)
    var car6 = car3.copy(6, "X2")
    var car7 = car3.copy(make = "Jaguar", model = "XE")

    println(car1)
    println(car1.getClass)

    println(car2)
    println(car2.getClass)

    println(car3)
    println(car3.getClass)

    println(car4)
    println(car4.getClass)

    println(car5)
    println(car5.getClass)
  }

  def UC3() {

    var car1 = new Car(1, "Q5", "Audi")
    var car2 = Car(2, "Q7", "Audi")
    var car3 = Car.apply(3, "X5", "BMW")

    println(car1)
    println(car1.getClass)

    println(car2)
    println(car2.getClass)

    println(car3)
    println(car3.getClass)
  }

  def UC2() {

    var car1 = new Car(1, "Q5", "Audi")
    var car2 = Car(2, "Q7", "Audi")

    println(car1)
    println(car1.getClass)

    println(car2)
    println(car2.getClass)

  }

  def UC1() {

    var car1 = new Car(1, "Q5", "Audi")
    var car2 = new Car(1, "Q7", "Audi")

    println(car1)
    println(car1.toString)

    println(car2)
    println(car2.toString)

    println(car1.hashCode)
    println(car2.hashCode)

    println(car1 == car2) //equality
    println(car1.equals(car2)) //equality

    println(car1.eq(car2)) //identity
    println(car1.ne(car2)) //identity
  }

}