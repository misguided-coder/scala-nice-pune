package com.example.caseclasses._3

case class Car(vin: Int, model: String, make: String)

object Main {

  def main(arg: Array[String]): Unit = {

    var car1 = new Car(1, "Q5", "Audi")
    var car2 = new Car(2, "Q7", "Audi")
    var car3 = new Car(3, "A1", "Audi")
    var car4 = new Car(4, "XE", "Jaguar")
    var car5 = new Car(5, "XF", "Jaguar")
    var car6 = new Car(6, "CLA", "Merc")

    //showCarDetails(car6)
    chooseCar(car6)
  }

  def chooseCar(car: Car): Unit = {

    car match {
      case Car(1, "Q5", "Audi")  => println("I just purchased Q5!!")
      case Car(2, "Q7", "Audi")  => println("I just purchased Q7!!")
      //case Car(vin, model, make) => println(s"I just purchased ${make} ${model}!!")
      case _: Car                => println("I just purchased Car!!")
      case _                     => println("I just purchased Plane!!")
    }
  }

  def showCarDetails(car: Car): Unit = {

    car match {
      case Car(1, "Q5", "Audi")   => println("I just purchased Q5!!")
      case Car(2, "Q7", "Audi")   => println("I just purchased Q7!!")
      case Car(3, "A1", "Audi")   => println("I just purchased A1!!")
      case Car(4, "XE", "Jaguar") => println("I just purchased XE!!")
      case Car(5, "XF", "Jaguar") => println("I just purchased XF!!")
      case _                      => println("I just purchased Plane!!")

    }
  }

}