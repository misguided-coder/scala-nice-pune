package com.example.caseclasses._4

object Main {

  trait Vehicle
  case class Car(name: String) extends Vehicle
  case class Bus(name: String) extends Vehicle
  case class Bike(name: String) extends Vehicle
  case object Erikshaw extends Vehicle

  def main(arg: Array[String]): Unit = {

    var car1 = new Car("Audi Q5")
    var car2 = new Car("Audi Q7")
    var bus = new Bus("Volvo 30 Seaater")
    var bike = new Bike("Yamaha Rx 100")

    useVehicle(Erikshaw)

  }

  def useVehicle(vehicle: Vehicle): Unit = {

    vehicle match {
      case Car("Audi Q5") => println("I am driving a Audi Q5!!")
      case _: Car         => println("I am driving a Car!!")
      case value: Bus     => println(s"I am driving ${value.name}!!")
      case Bike(name)     => println(s"I am driving a ${name}!!")
      case Erikshaw       => println("I am driving a Erikshaw!!")
      case _              => println("I am driving a Plane!!")
    }
  }

}