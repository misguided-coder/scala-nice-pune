package com.example._abstract

abstract class Shape(var version:Double = 1.0) {

  def draw() //abstract method
  def paint //abstract method

  //concrete method
  def info() {
    println(s"It is all about shapes and shape version is ${this.version}!!")
  }

}