package com.example.io

import java.io._
import scala.io._

object Main {

  def main(arg: Array[String]): Unit = {

    var data: String = """Life is cool
      Life is cool
      Life is cool
      Life is cool
      Life is cool
      Life is cool"""

    var fileUrl = "file:///C:/scala-workspace/nice/files/quotes.txt"
    //var filePath = "C:/scala-workspace/nice/files/quotes.txt"
    //var file = new File(filePath)

    var source: Source = null

    try {
      //source = Source.fromFile(file)
      //source = Source.fromFile(filePath)
      //source = Source.fromURL(fileUrl)
      source = Source.fromString(data)
      
      for (line <- source.getLines()) {
        println(line)
      }

      /*var iterator = source.getLines()
      for(line <- iterator) {
          println(line)
      }*/

      /*while (iterator.hasNext) {
        println(iterator.next)
      }*/
    } catch {
      case ex: FileNotFoundException => println("File is missing!!")
      case ex: IOException           => println("Error in reading File!!")
    } finally {
      source.close()
    }

  }

}