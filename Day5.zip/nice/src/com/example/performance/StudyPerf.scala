package com.example.performance

import java.util.concurrent.TimeUnit

object StudyPerf {

  var values: List[Int] = List()

  def main(arg: Array[String]): Unit = {

    var idx = 0
    while (idx < 2000000) {
      var list = values.+:(idx)
      println("Writing....")
      TimeUnit.MILLISECONDS.sleep(500)
    }

  }

}