package com.example.for_comprehension

import scala.collection.immutable.Range

object Main {

  def main(arg: Array[String]): Unit = {
    //UC1()
    //UC2()
    //UC3()
    //UC4()
    //UC5()
    //UC6()
    //UC7()
    //UC8()
    //UC9()
    //UC10()
    //UC11()
    //UC12()
    UC13()

  }

  def UC13() {
    var numbers = Array.ofDim[Int](4, 2)

    for (i <- 0 to 3; j <- 0 to 1) {
      numbers(i)(j) = (Math.random() * 1000 + i + j).toInt
    }

    for (array <- numbers;value <- array) {
      println(s"${value}")
    }

  }

  def UC12() {
    var numbers = Array.ofDim[Int](4, 2)

    for (i <- 0 to 3; j <- 0 to 1) {
      numbers(i)(j) = (Math.random() * 1000 + i + j).toInt
    }

    for (i <- 0 to 3; j <- 0 to 1) {
      printf(s"${numbers(i)(j)}\t")
    }

  }

  def UC11() {
    var names = Array("Rani", "Ramu", "Chachu", "Ganshu", "Papa Jon", "Rancho", "Sudhir",
      "Pintu", "Jaggu", "Chandu", "Gabbar", "Lalu Yadav", "Kalia Khatarnak", "Kallu Don", "Rani Patiala",
      "Rose Gulabi", "Laden Humble", "Dawood Raja")

    for (
      name: String <- names;
      if name.startsWith("R");
      result = name.toUpperCase;
      if result.length() > 4
    ) {
      println(s"${result}")
    }
  }

  def UC10() {
    var names = Array("Rani", "Ramu", "Chachu", "Ganshu", "Papa Jon", "Rancho", "Sudhir",
      "Pintu", "Jaggu", "Chandu", "Gabbar", "Lalu Yadav", "Kalia Khatarnak", "Kallu Don", "Rani Patiala",
      "Rose Gulabi", "Laden Humble", "Dawood Raja")

    for (name: String <- names) {
      println(s"${name}")
    }
  }

  def UC9() {
    var names = Array("Rani", "Ramu", "Chachu", "Ganshu", "Papa Jon", "Rancho", "Sudhir",
      "Pintu", "Jaggu", "Chandu", "Gabbar", "Lalu Yadav", "Kalia Khatarnak", "Kallu Don", "Rani Patiala",
      "Rose Gulabi", "Laden Humble", "Dawood Raja")

    var itr = names.iterator

    while (itr.hasNext) {
      println(s"${itr.next}")
    }
  }

  def UC8() {
    var names = Array("Rani", "Ramu", "Chachu", "Ganshu", "Papa Jon", "Rancho", "Sudhir",
      "Pintu", "Jaggu", "Chandu", "Gabbar", "Lalu Yadav", "Kalia Khatarnak", "Kallu Don", "Rani Patiala",
      "Rose Gulabi", "Laden Humble", "Dawood Raja")

    for (idx <- 0 until names.length) {
      println(s"${idx} ----- ${names(idx)}")
    }
  }

  def UC7() {

    for (i <- 1 to 50; value = i * i; if value > 400) {
      println(s"Square of ${i} is ${value}")
    }
  }

  def UC6() {

    for (i <- 1 to 50; if i % 10 == 0 || i % 5 == 0) {
      println(s"I : ${i}")
    }
  }

  def UC5() {

    for (i <- 1 to 50; if i % 10 == 0; j <- 1 to 20; if j % 5 == 0) {
      println(s"I : ${i} and J : ${j}")
    }
  }

  def UC4() {

    for (i <- 1 to 5; j <- 1 to 2; k <- 1 to 4) {
      println(s"I : ${i} and J : ${j} and K : ${k}")
    }
  }

  def UC3() {

    for (value <- 20 to 1 by -1) {
      println(s"Value is : ${value}")
    }
  }

  def UC2() {

    //var range = 1 to 20
    //var range = 1 until 20

    //for comprehension
    for (value <- 1 to 20 by 2) {
      println(s"Value is : ${value}")
    }

  }

  def UC1() {

    var range = Range.Int.inclusive(1, 20, 1)
    //var range = 1 to 20
    //var range = 1 until 20

    println(range)
    println(range getClass)

    //for comprehension
    for (value <- range) {
      println(s"Value is : ${value}")
    }

  }

}