package com.example.collection

object TupleDemo {

  def main(arg: Array[String]): Unit = {

    //var values = Tuple3("Raj", 24, "raj@gmail.com")
    var values = ("Raj", 24, "raj@gmail.com")

    println(values._1)
    println(values._2)
    println(values._3)

    println(values)
    println(values getClass)

    for (value <- values.productIterator) {
      println(value)
    }

    var (a, _, c) = values
    println(a)
    println(c)

    println(values.toString())

    var result = readStudentByRollNo(1)
    println(result)

    for (value <- readStudentByRollNo(1).productIterator) {
      println(value)
    }

  }

  def readStudentByRollNo(rollNo: Int) = {
    //DB call
    (rollNo, "Ram", "10th Standard", 16)
  }

}