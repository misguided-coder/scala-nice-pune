package com.example.collection

import scala.collection.immutable._
import scala.collection.immutable.{ List, Seq, Set }

object MapDemo {

  def main(arg: Array[String]): Unit = {

    //var employees:Map[Int,String] = Map[Int,String](100 -> "Ram",200 -> "Jaggu",300 -> "Pintu")
    //var employees = Map[Int,String](100 -> "Ram",200 -> "Jaggu",300 -> "Pintu")
    //var employees = Map(100 -> "Ram", 200 -> "Jaggu", 300 -> "Pintu")
    var employees = Map.empty[Int, String]
    employees = employees + (100 -> "Ram") + (200 -> "Jaggu")
    println(employees)

    println(employees.get(100))
    println(employees(100))

    for ((k, v) <- employees) {
      println(k)
      println(v)
    }

    for (k <- employees.keys)
      println(k)

    for (v <- employees.values)
      println(v)

    //employees.foreach((key, value) => println(s"Key : $key and Value : $value"))

  }

}