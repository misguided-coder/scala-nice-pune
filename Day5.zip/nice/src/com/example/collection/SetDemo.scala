package com.example.collection

import scala.collection.immutable._
import scala.collection.immutable.{ List, Seq, Set }

object SetDemo {

  def main(arg: Array[String]): Unit = {

    var set1 = Set("Jan", "Feb", "Mar", "Jan")
    var set2 = Set("Apr", "May", "Feb")

    var set3 = set1 ++ set2

    var set4 = set3 + "Dec"

    var set5 = set4 - "Jan"

    println(set1)
    println(set2)
    println(set3)
    println(set4)
    println(set5)

  }

}