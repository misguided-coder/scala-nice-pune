package com.example.collection

object OptionDemo {

  def main(arg: Array[String]): Unit = {

    var value1: Option[String] = Some("Red Color")
    var value2: Option[String] = None

    println(value1.isEmpty)
    //println(value1.get)
    println(value1.getOrElse("Yellow Color"))

    println(value2.isEmpty)
    println(value2.getOrElse("Black Color"))
    //println(value2.get)

    var result = chooseCar("Audi")
    println(result.toUpperCase())
    
    var container = readCar("Audi")
    if(!container.isEmpty) {
      println(container.get.toUpperCase())
    }
    
    var cont = readCar("Santro")
    
    cont match {
      case Some(v) => println(s"Value is ${v}")
      case None => println(s"No Value")
    }
    
    for(car <- readCar("BMW")) {
       println(car)
    }
    
  }

  def readCar(make: String): Option[String] = {
    if (make.equals("Audi")) {
      return Some("Audi Q5")
    } else if (make.equals("Jaguar")) {
      return Some("Jaguar Xe")
    } else if (make.equals("BMW")) {
      return Some("BMW X1")
    }
    return None
  }

  def chooseCar(make: String): String = {
    if (make.equals("Audi")) {
      return "Audi Q5"
    } else if (make.equals("Jaguar")) {
      return "Jaguar Xe"
    } else if (make.equals("BMW")) {
      return "BMW X1"
    }
    return null
  }

}