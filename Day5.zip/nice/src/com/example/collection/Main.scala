package com.example.collection

import scala.collection.immutable._
import scala.collection.immutable.{ List, Seq, Set }

object Main {

  def main(arg: Array[String]): Unit = {
    //UC1
    //UC2
    //UC3
    //UC4
    //UC5
    //UC6
    UC7

  }

  def UC7 {
    var numbers = List.range(10, 100, 5)

    println(s"Original : ${numbers}")
    println(numbers take 10 drop 2 tail)

    /*println(numbers.take(5))
    println(numbers.takeRight(5))
    */

    //println(numbers.drop(4))
    //println(numbers.dropRight(4))

    /*println(s"Head : ${numbers.head}")
    println(s"Tail : ${numbers.tail}")
    println(s"Tail : ${numbers.last}")
    */

    /*println(s"Max : ${numbers.max}")
    println(s"Min : ${numbers.min}")
    println(s"SUM : ${numbers.sum}")
    */

    //numbers.foreach((value) => { println(value) })
    //numbers.foreach((value) => println(value))
    //numbers.foreach(println(_))
    //numbers.foreach(println _)
    //numbers.foreach(println)
    //var squares = numbers.map((value) => value * value)
    //println(s"Mapper : ${squares}")

    //var resultList = numbers.map((value) => s"Value : ${value}")
    //var resultList = numbers.map((value) => value + 10)
    //println(s"Mapper : ${resultList}")

    /*var resultList = numbers.filter((value) => {
      var square = value * value
      square > 400
    })

    println(s"Filtered : ${resultList}")*/

  }

  def UC6 {
    var numbers = List(10, 20, 30, 40)

    println(s"Before : ${numbers}")

    var updatedList = 50 :: numbers

    println(s"After : ${numbers}")
    println(s"After : ${updatedList}")
  }

  def UC5 {
    //var list1 = List.fill[String](10)("Namaste")
    //var list1:List[String] = List.fill[String](10)("Namaste")
    //var list1:List[String] = List.fill(10)("Namaste")
    //var list1 = List.fill(10)("Namaste")
    //var list1 = List.fill(10,4)("Namaste")
    //var list1 = List.range(1, 2000, 50)
    //var list1 = List.iterate(1, 5)((value) => { value + 10 })
    //var list1 = List.tabulate[String](10)((value)=> s"Value is ${value}")
    //var list1 = List.tabulate[String](10)((value)=> s"Square : ${value * value}")
    var list1 = List.tabulate(10, 2)((i, j) => s"Sum : ${i + j}")

    println(list1)
    println(list1.isEmpty)
    println(list1.size)

  }

  def UC4 {
    //var list1 = List[String]()
    //var list1 = List()
    //var list1 = List.empty[String]
    //var list1 = Nil

    var list1 = 10 :: 20 :: 30 :: Nil

    println(list1)
    println(list1.isEmpty)
    println(list1.size)

  }

  def UC3 {
    var list1 = List(10, 20, 30)
    var list2 = List(40, 50, 60, 70, 80, 90)

    var list3 = List.concat(list1, list2)
    var list4 = list1.:::(list2)
    var list5 = list1 ::: list2

    println(list3)
    println(list4)
    println(list5)
  }

  def UC2 {
    //var numbers:List[Int] = List[Int](40, 50, 60, 70,80,90)
    //var numbers = List[Int](40, 50, 60, 70,80,90)
    var numbers = List(40, 50, 60, 70, 80, 90)

    println(numbers)
    println(numbers getClass)

    for (value <- numbers) {
      println(value)
    }
  }

  def UC1 {
    var numbers = Seq(4, 5, 6, 7)

    println(numbers)
    println(numbers getClass)

    for (value <- numbers) {
      println(value)
    }
  }

}