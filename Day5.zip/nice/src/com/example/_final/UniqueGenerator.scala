package com.example._final

class UniqueGenerator extends Generator {
  
}