package com.example.traits

class SimpleQuote extends Quote {

  def nextQuote(): String = {
    "Someone give me loan and leave me alone"
  }
}