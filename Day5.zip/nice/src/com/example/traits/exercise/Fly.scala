package com.example.traits.exercise

trait Fly extends Car {
  def canFly()  
}