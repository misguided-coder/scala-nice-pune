package com.example.traits.exercise

class Bus extends Vehicle with Acceleratable with Repairable {

  var speed: Int = 50

  override def start() {
    println("Bus engine is just switched on using key!!")
  }

  def speedUp() {
    this.speed += 10
    println(s"Bus is speeding up and current speed is ${this.speed} miles per hour!!")
  }

  def repair() {
    println(s"Bus is repaired!!")
  }

}