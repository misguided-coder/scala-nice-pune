package com.example.traits.exercise

trait Acceleratable extends Automobile {
  def speedUp   
}