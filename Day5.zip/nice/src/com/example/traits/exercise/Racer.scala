package com.example.traits.exercise

object Racer extends PrettyLogger {

  def doRace(vehicle: Acceleratable) {
    log("Racer is ready to race!!")
    vehicle.start
    vehicle.speedUp
    vehicle.speedUp
    vehicle.speedUp
    vehicle.speedUp
    vehicle.speedUp
    vehicle.speedUp
    vehicle.stop
    log("Racer finished the race!!")
  }

}