package com.example.traits.exercise

class Car extends Vehicle with Acceleratable with Washable with Repairable with PrettyLogger with Logger {

  var speed: Int = 80

  override def log(message: String) {
    super.log(message)
  }
  override def start() {
    this.log("Car engine is just switched on using button press!!")
  }

  def speedUp() {
    this.speed += 10
    println(s"Car is speeding up and current speed is ${this.speed} miles per hour!!")
  }

  override def clean() {
    println(s"Car washing is done!!")
  }

  def repair() {
    println(s"Car is repaired!!")
  }

}