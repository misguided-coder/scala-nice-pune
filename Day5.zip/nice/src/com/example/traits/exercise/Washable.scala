package com.example.traits.exercise

trait Washable {
  def clean() {
    println(s"Vehicle washing is done!!")
  }
}