package com.example.traits.exercise

object Mechanic {

  def doRepair(vehicle: Repairable) {
    println("Mechanic is ready to repair!!")
    vehicle.repair
    println("Mechanic finished the repairing!!")
  }

}