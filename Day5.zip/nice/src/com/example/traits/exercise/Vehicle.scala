package com.example.traits.exercise

class Vehicle extends Automobile with Brakable with Runnable {

  def speedDown() {
   println("Vehicle is slowing down!!")
  }

  override def start() {
    println("Vehicle engine is just switched on!!")
  }
  
  override def run() {
    println("Vehicle is just running!!")
  }

}