package com.example.traits.exercise

import java.time.LocalDateTime

trait PrettyLogger {

  def log(message: String) {
    println(s"INFO -- ${LocalDateTime.now()} ---- $message")
  }
}