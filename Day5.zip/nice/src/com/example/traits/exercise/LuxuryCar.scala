package com.example.traits.exercise

class LuxuryCar extends Car with Fly {

  override def start() {
    println("LuxuryCar engine is just switched on using voice command!!")
  }

  override def speedUp() {
    this.speed += 20
    println(s"LuxuryCar is speeding up and current speed is ${this.speed} miles per hour!!")
  }

  override def canFly() {
    println(s"LuxuryCar is is cabaple of flying!!")
  }

}