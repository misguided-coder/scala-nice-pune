package com.example.traits

class EveryDayQuote extends Quote with QuoteSupplier {

  def addQuote(quote: String): Unit = {
    this.quotes + "New quote added"   
  }

  def nextQuote(): String = {
    var array = loadQuotes
    array((Math.random()* array.length-1).toInt)
  }
}