package com.example.traits

trait Quote {
  
  def nextQuote : String //abstract method
}