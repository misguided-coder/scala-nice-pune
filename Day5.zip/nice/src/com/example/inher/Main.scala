package com.example.inher

object Main {

  def main(arg: Array[String]): Unit = {
    
    var furniture = new Furniture(1,"Iron",2000.00)
    furniture.info
    furniture.make
    furniture.paint
    furniture.sell
    
    var chair1 = new Chair
    chair1.make
    chair1.paint
    chair1.sell
    
    var chair2 = new Chair(10,"Plastic",8000.00)
    chair2.make
    chair2.paint
    chair2.sell
    
    println(chair2.legs)
    println(chair2.hands)
    
    chair2.info
    
    var chair3 = new Chair(100,"Wood",9000.00,2,1)
    chair3.info
    chair3.make
    chair3.paint
    chair3.sell
    
    
  }

}