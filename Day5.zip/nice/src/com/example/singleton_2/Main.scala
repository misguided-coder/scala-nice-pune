package com.example.singleton_2

object Main {

  def main(arg: Array[String]): Unit = {

    var airport1 = Airport.getInstance
    var airport2 = Airport.getInstance

    println(airport1)
    println(airport2)

    airport1.info
    airport2.info

    println(airport1.hashCode())
    println(airport2.hashCode())

  }

}