package com.example.caseclasses._2

case class Car(vin: Int, model: String, make: String)(price: Double = 100000.00, color: String = "Black") {

  def display() {
    println(this.vin)
    println(this.model)
    println(this.make)
  }

  def sell() {
    println(s"Car selling price is ${price}")
  }

}

object Main {

  def main(arg: Array[String]): Unit = {

    var car1 = new Car(1, "Q5", "Audi")(100000.00, "White")
    var car2 = new Car(1, "Q5", "Audi")(500000.00, "Yellow")

    println(car1.eq(car2))
    
    println(car1 == car2)
    println(car1.equals(car2))
    
    println(car1.hashCode())
    println(car2.hashCode())
    
    car1.sell()
    car2.sell()
    
    
    
  }
}