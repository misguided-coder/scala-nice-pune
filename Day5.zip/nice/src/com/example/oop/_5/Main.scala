package com.example.oop._5

object Main {

  def main(arg: Array[String]): Unit = {
    
    var i:Int = 10000
    println(i)
    
    //var j = i + 5000
    var j = i.+(5000)
    println(j)
    
    println(i == j)
    println(i.==(j))
    println(i ==(j))
    
    var size1 = new Size(400,200)
    var size2 = new Size(600,200)
    
    size1.info
    size2.info
 
    //var size3 = size1.plus(size2)
    //var size3 = size1 plus(size2)
    //var size3 = size1 plus size2
    //var size3 = size1.+(size2)
    //var size3 = size1 +(size2)
    //var size3 = size1 + size2
    var size3 = size1 - size2
     
    size3.info
  
  }

}