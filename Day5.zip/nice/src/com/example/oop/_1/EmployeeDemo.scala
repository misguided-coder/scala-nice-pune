package com.example.oop._1

object EmployeeDemo {

  def main(arg: Array[String]): Unit = {
    //UC1()
    //UC2()
    //UC3()
    UC4()
  }

  def UC4() {
    var e1 = new Employee()
    var e2 = new Employee()

    e1.info()
    e1.applyForLeave()
    e1.assignProject("Core Banking App")
    e1.updateSalary(0.60)
  }

  def UC3() {
    var e1 = new Employee()
    var e2 = new Employee()

    e1.info()
    e1.info
    e1 info

    e2.info()
  }

  def UC2() {
    var e1 = new Employee()
    var e2 = new Employee()
    println(e1.id)
    println(e1 id)
    println(e1.name)
    println(e1 name)
    println(e1.salary)
    println(e1 salary)

    println("========================")

    println(e2.id)
    println(e2.name)
    println(e2.salary)

  }

  def UC1() {
    //var e1:Employee = new Employee()
    var e1 = new Employee()

    println(e1)
    println(e1 getClass)
  }

}