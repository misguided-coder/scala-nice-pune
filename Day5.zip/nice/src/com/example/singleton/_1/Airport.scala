package com.example.singleton._1

object Airport {

  var title = "Indira Gandgi International Airport"
  var capacity: Int = 50000
  var planes: Int = 50
  var landedPlanes: Int = 10

  def info {
    println(s"${title}")
    println(s"Passanger Capacity : ${capacity}")
    println(s"Plane Capacity : ${planes}")
    println(s"Landed Planes : ${landedPlanes}")
    println("============================================")
  }

  def isSpaceAvailableForLanding(): Boolean = {
    if (landedPlanes < planes) {
      true
    } else {
      false
    }
  }

  def landPlane() = {
    if (isSpaceAvailableForLanding()) {
      landedPlanes += 1
    }
  }

}