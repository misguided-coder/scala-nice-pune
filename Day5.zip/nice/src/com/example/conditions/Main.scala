package com.example.conditions

import scala.collection.immutable.Range

object Main {

  def main(arg: Array[String]): Unit = {
    //UC1()
    //UC2()
    //UC3()
    UC4()
    //UC5()

  }

  //Java way
  def UC5() {

    var age = 20
    var result: String = ""

    if (age <= 20)
      result = "You are young"
    else
      result = "You are grown"

    println(result)
  }

  //Scala way
  def UC4() {

    var age = 20

    var result = if (age <= 20) {
      s"Your age is ${age}"
      20 + 5
      println("I am talking to friends!!")
      "You are young"
    } else {
      s"Your age is ${age}"
      20 + 10
      println("I am talking to family!!")
      "You are grown"
    }

    println(result)
  }

  def UC3() {

    var age = 24

    if (age <= 20)
      println("You are young")
    else
      println("You are grown")

  }

  def UC2() {

    var i = 101

    if (i == 100) {
      println("Truthy")
    } else {
      println("Falsy")
    }

  }

  def UC1() {

    var i = 100
    //if(true){
    if (i == 100) {
      println("Truthy")
    }

  }

}